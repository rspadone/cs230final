import pandas as pd
import matplotlib.pyplot as plt
from streamlit import bar_chart


def print_data(df):

    print("Standard Formatting")
    print(df[['first_name','last_name','salary','department_id']])
    print("----")
    print("Custom Formatting")
    print("First name      Last name      Salary    Department ID")
    for index, row in df.head(10).iterrows():
        print(f"{row['first_name']:<15s} {row['last_name']:<15s} ${row['salary']:9.2f} {row['department_id']:3.0f}")


def last_name_filter(letter, df):
    result = df[df['last_name'].str[:1]==letter]
    print_data(result)

def salary_filter(salary, df):
    result = df[df['salary']>=salary]
    return result  #this one returns the df as a result

def histogram(df):
    num_bins = 5
    plt.title("Salary Ranges")
    plt.hist(df["salary"], num_bins, facecolor='blue')
    plt.show()



employees = pd.read_excel("employees.xlsx")
print_data(employees)

letter = input("Find employees with last name starting with: ")
letter = letter.upper()
last_name_filter(letter, employees)

salary = float(input("Find employees with salary greater than:"))
df_result = salary_filter(salary, employees)
print_data(df_result)

histogram (df_result)
histogram(employees)

